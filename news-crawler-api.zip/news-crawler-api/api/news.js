const RSSParser = require('rss-parser');
const { Configuration, OpenAIApi } = require('openai');
const translate = require('@vitalets/google-translate-api');

const parser = new RSSParser();

// 你需要将 OPENAI_API_KEY 设置为你的环境变量
const openai = new OpenAIApi(
  new Configuration({
    apiKey: process.env.sk-i34aSQBnUuzuTY2U378f595f46Ff486b8b0dD1496c038a0f, // 这里填你的 V-API key
    basePath: 'https://api.vveai.com', // 这里是 V-API 的 endpoint
  })
);

async function summarize(text) {
  // 用 OpenAI 生成摘要
  const prompt = `请用简体中文总结以下新闻内容，50字以内：\n${text}`;
  const completion = await openai.createChatCompletion({
    model: 'gpt-3.5-turbo',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 100,
    temperature: 0.5,
  });
  return completion.data.choices[0].message.content.trim();
}

async function translateToChinese(text) {
  // 用 Google Translate API 翻译为中文
  try {
    const res = await translate(text, { to: 'zh-CN' });
    return res.text;
  } catch (e) {
    return text;
  }
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }
  const { rssList } = req.body;
  if (!Array.isArray(rssList) || rssList.length === 0) {
    res.status(400).json({ error: 'rssList is required' });
    return;
  }
  let allNews = [];
  for (const rssUrl of rssList) {
    try {
      const feed = await parser.parseURL(rssUrl);
      for (const item of feed.items.slice(0, 5)) { // 每个源只取最新5条
        let summary = item.contentSnippet || item.content || item.title;
        // 先用英文摘要（如有内容）
        if (summary.length > 200) summary = summary.slice(0, 200);
        let zhSummary = await summarize(summary);
        // 如果原文不是中文，强制翻译标题和摘要
        let zhTitle = await translateToChinese(item.title);
        if (!/[\u0000-\u007f]+/.test(item.title)) zhTitle = item.title; // 已是中文
        allNews.push({
          title: zhTitle,
          summary: zhSummary,
          url: item.link,
          date: item.isoDate || item.pubDate || '',
        });
      }
    } catch (e) {
      // 某个源失败不影响整体
      continue;
    }
  }
  res.status(200).json({ news: allNews });
};